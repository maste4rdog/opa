# Roda o agente localmente no Windows (PowerShell), sem Docker.
Set-Location -Path $PSScriptRoot

if (-not (Test-Path ".venv")) {
    Write-Host "Criando ambiente virtual..."
    python -m venv .venv
}

.\.venv\Scripts\Activate.ps1
pip install --quiet --upgrade pip
pip install --quiet -r requirements.txt

if (-not (Test-Path ".env")) {
    Write-Host "Nenhum .env encontrado - copiando .env.example. Edite antes de continuar."
    Copy-Item ".env.example" ".env"
}

streamlit run app/streamlit_app.py
