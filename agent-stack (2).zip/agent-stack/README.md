# Agent Stack — Streamlit + LiteLLM + MCP Gateway + RAG + Skills

> 📘 Para instruções detalhadas de uso (rodar nos dois modos, adicionar
> MCPs/tools novas, usar o RAG, e como janela de contexto/chunking são
> tratados), veja **[GUIA_DE_USO.md](./GUIA_DE_USO.md)**.

Agente com tool-calling (SDK oficial `openai`, apontado para o seu LiteLLM
externo), com histórico de chat persistente, capaz de:

- **Criar e usar skills** com a mesma anatomia que a Anthropic usa
  internamente (`SKILL.md` + `scripts/` + `references/` + `assets/`,
  progressive disclosure — ver seção dedicada abaixo).
- **Ler arquivos** enviados (pdf, docx, xlsx, csv, txt).
- **Gerar documentos** (docx, pdf, pptx, xlsx) como saída final.
- **RAG** local com ChromaDB persistente (embeddings via LiteLLM).
- **Chamar tools de servidores MCP** através do seu MCP Gateway existente.
- **Planejar tarefas** (plan_tasks/update_task/list_tasks) para pedidos
  multi-etapa, igual eu faço internamente com listas de tarefas.

O mesmo código em `app/` roda das duas formas abaixo — só muda como você
sobe o processo.

## Opção A — Docker

```bash
cp .env.example .env
# edite .env: LITELLM_BASE_URL/KEY, LLM_MODEL, EMBEDDING_MODEL, MCP_GATEWAY_URL
docker compose up --build
```

Acesse `http://localhost:8501`.

**Conectividade com LiteLLM/MCP Gateway externos:**
- Rodando no host: `http://host.docker.internal:<porta>` (já habilitado via
  `extra_hosts` no `docker-compose.yml`).
- Rodando em outra stack docker: conecte este serviço na mesma rede docker
  deles, ou exponha a porta no host.
- Endpoint remoto (https): usar a URL normalmente.

## Opção B — Python puro, sem Docker

Requer Python 3.11+.

**Linux/Mac:**
```bash
./run_local.sh
```

**Windows (PowerShell):**
```powershell
.\run_local.ps1
```

Isso cria um `.venv`, instala as dependências, copia `.env.example` para
`.env` na primeira vez (edite antes de rodar de novo) e sobe o Streamlit em
`http://localhost:8501`.

Manualmente, se preferir:
```bash
python3 -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env             # edite com suas configs
streamlit run app/streamlit_app.py
```

Nesse modo, como não tem rede docker isolada, `LITELLM_BASE_URL` e
`MCP_GATEWAY_URL` no `.env` devem apontar direto para `localhost` (ou o
host/porta reais), sem `host.docker.internal`.

## Estrutura

```
agent-stack/
├── docker-compose.yml / Dockerfile   # Opção A
├── run_local.sh / run_local.ps1      # Opção B
├── requirements.txt                   # usado nas duas opções
├── .env.example
└── app/
    ├── config.py
    ├── llm_client.py           # OpenAI SDK -> base_url do LiteLLM
    ├── streamlit_app.py         # UI
    ├── agent/
    │   ├── core.py              # loop de tool-calling
    │   ├── tools_registry.py    # schemas + dispatcher de todas as tools
    │   └── tasks.py             # planejamento (plan_tasks/update_task/list_tasks)
    ├── skills/
    │   ├── manager.py
    │   └── library/
    │       ├── skill-creator/    # meta-skill: como criar/editar skills
    │       └── exemplo-resumo/
    ├── rag/store.py
    ├── mcp/client.py            # cliente MCP (streamable-http) p/ seu gateway
    └── tools/{file_reader,doc_generator}.py
```

## Como as skills funcionam (mesmo padrão que eu uso)

```
skill-name/
├── SKILL.md (obrigatório)
│   ├── frontmatter: description, type, parameters, mcp_tool
│   └── corpo em markdown com as instruções
├── scripts/     - código executável (só para type=script)
├── references/  - documentação carregada SOB DEMANDA
└── assets/      - arquivos usados na saída (templates, etc.)
```

**Progressive disclosure:** só o `name` + `description` de cada skill fica
sempre visível pro agente (é o que vira o schema da tool). O corpo do
`SKILL.md` só entra em contexto quando a skill é chamada. Arquivos em
`references/`/`assets/` só entram quando lidos explicitamente via
`read_skill_resource`. Isso mantém o custo de contexto baixo mesmo com
muitas skills cadastradas.

**Cada skill vira sua própria tool automaticamente:** assim que criada
(`create_skill`), ela já aparece como `skill__<nome>` na lista de tools do
agente — inclusive na mesma resposta em que foi criada, sem precisar de um
novo turno. Três tipos:

- `type: instruction` — texto que o agente segue ao ser chamado.
- `type: script` — executa `scripts/run.py` com os argumentos em JSON.
- `type: mcp` — encapsula/cura uma tool específica do MCP Gateway, com
  nome e parâmetros mais claros que o original.

**Skill-creator:** existe uma skill `skill-creator` (`app/skills/library/skill-creator/SKILL.md`)
com o guia completo de como escrever uma boa skill — captura de intenção,
descrição "pushy" (pra evitar sub-acionamento), quando usar cada `type`,
princípio da não-surpresa, e como testar antes de criar de fato. O agente é
instruído a consultá-la sempre que o pedido for "criar/editar/otimizar uma
skill". Ela é uma skill de verdade (não código hardcoded) — você pode ler e
editar `app/skills/library/skill-creator/SKILL.md` livremente.

**Empacotar:** `package_skill(nome)` gera um `.skill` (zip com SKILL.md +
scripts/ + references/ + assets/) em `data/outputs`, baixável pela sidebar
— útil pra levar a skill pra outro ambiente/instalação.

## Pontos de ajuste importantes

1. **`LLM_MODEL` / `EMBEDDING_MODEL`** — precisam bater com os `model_name`
   cadastrados no seu LiteLLM.
2. **`MCP_GATEWAY_URL`** — o cliente usa `streamable-http`. Se seu gateway
   fala SSE puro, troque `streamablehttp_client` por `sse_client`
   (`mcp.client.sse`) em `app/mcp/client.py` — assinatura quase idêntica.
3. **Autenticação do gateway** — hoje é Bearer simples
   (`MCP_GATEWAY_TOKEN`). Ajuste `_headers()` em `mcp/client.py` se for
   outro esquema (mTLS, OAuth2 client-credentials, etc).

## Próximos passos sugeridos

- Trocar SQLite por Postgres se for multiusuário.
- Adicionar streaming de tokens no `chat_completion` + `st.write_stream`.
- Auth na frente do Streamlit (`streamlit-authenticator` ou atrás do seu
  próprio OIDC/gateway) antes de expor externamente.
