#!/usr/bin/env bash
# Roda o agente localmente, sem Docker.
set -e

cd "$(dirname "$0")"

if [ ! -d ".venv" ]; then
    echo "Criando ambiente virtual..."
    python3 -m venv .venv
fi

source .venv/bin/activate
pip install --quiet --upgrade pip
pip install --quiet -r requirements.txt

if [ ! -f ".env" ]; then
    echo "Nenhum .env encontrado — copiando .env.example. Edite antes de continuar."
    cp .env.example .env
fi

streamlit run app/streamlit_app.py
