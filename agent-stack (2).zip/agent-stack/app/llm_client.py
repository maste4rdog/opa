"""
Wrapper fino sobre o SDK oficial da OpenAI, apontado para o seu proxy LiteLLM.
Como o LiteLLM expõe uma API compatível com OpenAI, usamos o client normal
apenas trocando base_url + api_key.
"""
from openai import OpenAI
from app import config

client = OpenAI(
    base_url=config.LITELLM_BASE_URL,
    api_key=config.LITELLM_API_KEY,
)


def chat_completion(messages, tools=None, model: str | None = None, **kwargs):
    return client.chat.completions.create(
        model=model or config.LLM_MODEL,
        messages=messages,
        tools=tools or None,
        tool_choice="auto" if tools else None,
        **kwargs,
    )


def embed(texts: list[str], model: str | None = None):
    resp = client.embeddings.create(
        model=model or config.EMBEDDING_MODEL,
        input=texts,
    )
    return [d.embedding for d in resp.data]
