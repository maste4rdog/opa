import os

import pandas as pd
from docx import Document
from pypdf import PdfReader

MAX_CHARS = 20000


def read_file(path: str) -> str:
    if not os.path.exists(path):
        return f"Arquivo não encontrado: {path}"

    ext = os.path.splitext(path)[1].lower()

    try:
        if ext == ".pdf":
            text = _read_pdf(path)
        elif ext == ".docx":
            text = _read_docx(path)
        elif ext in (".xlsx", ".xls"):
            text = _read_excel(path)
        elif ext == ".csv":
            text = pd.read_csv(path).to_string()
        else:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                text = f.read()
    except Exception as e:
        return f"Erro ao ler {path}: {e}"

    if len(text) > MAX_CHARS:
        text = text[:MAX_CHARS] + f"\n\n[...truncado, arquivo tem {len(text)} caracteres...]"
    return text


def _read_pdf(path: str) -> str:
    reader = PdfReader(path)
    parts = []
    for i, page in enumerate(reader.pages):
        parts.append(f"--- página {i + 1} ---\n{page.extract_text() or ''}")
    return "\n".join(parts)


def _read_docx(path: str) -> str:
    doc = Document(path)
    return "\n".join(p.text for p in doc.paragraphs)


def _read_excel(path: str) -> str:
    xls = pd.read_excel(path, sheet_name=None)
    parts = []
    for sheet_name, df in xls.items():
        parts.append(f"--- aba: {sheet_name} ---\n{df.to_string()}")
    return "\n".join(parts)
