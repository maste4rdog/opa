import os

from docx import Document
from openpyxl import Workbook
from pptx import Presentation
from pptx.util import Inches
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet

from app import config


def _out_path(filename: str) -> str:
    return os.path.join(config.OUTPUTS_DIR, filename)


def generate_docx(title: str, sections: list[dict], filename: str) -> str:
    """sections: [{"heading": str, "text": str}, ...]"""
    doc = Document()
    doc.add_heading(title, level=0)
    for sec in sections:
        if sec.get("heading"):
            doc.add_heading(sec["heading"], level=1)
        doc.add_paragraph(sec.get("text", ""))
    path = _out_path(filename)
    doc.save(path)
    return path


def generate_pdf(title: str, sections: list[dict], filename: str) -> str:
    path = _out_path(filename)
    styles = getSampleStyleSheet()
    story = [Paragraph(title, styles["Title"]), Spacer(1, 16)]
    for sec in sections:
        if sec.get("heading"):
            story.append(Paragraph(sec["heading"], styles["Heading2"]))
        story.append(Paragraph(sec.get("text", "").replace("\n", "<br/>"), styles["Normal"]))
        story.append(Spacer(1, 12))
    SimpleDocTemplate(path, pagesize=A4).build(story)
    return path


def generate_pptx(title: str, slides: list[dict], filename: str) -> str:
    """slides: [{"title": str, "bullets": [str, ...]}, ...]"""
    prs = Presentation()
    title_slide_layout = prs.slide_layouts[0]
    slide = prs.slides.add_slide(title_slide_layout)
    slide.shapes.title.text = title

    bullet_layout = prs.slide_layouts[1]
    for s in slides:
        slide = prs.slides.add_slide(bullet_layout)
        slide.shapes.title.text = s.get("title", "")
        body = slide.placeholders[1].text_frame
        for i, bullet in enumerate(s.get("bullets", [])):
            p = body.paragraphs[0] if i == 0 else body.add_paragraph()
            p.text = bullet

    path = _out_path(filename)
    prs.save(path)
    return path


def generate_xlsx(sheet_name: str, rows: list[list], filename: str) -> str:
    wb = Workbook()
    ws = wb.active
    ws.title = sheet_name
    for row in rows:
        ws.append(row)
    path = _out_path(filename)
    wb.save(path)
    return path
