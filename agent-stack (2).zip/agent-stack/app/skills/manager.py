"""
Skills seguem a MESMA anatomia usada internamente pela Anthropic:

    skill-name/
    ├── SKILL.md (obrigatório)
    │   ├── frontmatter YAML-like (name, description, + extensões nossas)
    │   └── corpo em markdown com as instruções
    ├── scripts/     - código executável para tarefas determinísticas/repetitivas
    ├── references/  - documentação carregada sob demanda (não vai pro contexto
    │                  até o agente pedir explicitamente via read_skill_resource)
    └── assets/      - arquivos usados na saída (templates, etc.)

Progressive disclosure (mesmo princípio de lá):
1. Metadata (name + description) -> sempre visível, é o que vira o schema
   da tool na lista de tools do agente.
2. Corpo do SKILL.md -> só entra em contexto quando a skill é chamada.
3. scripts/references/assets -> só carregados quando explicitamente
   executados/lidos.

Frontmatter suportado:
---
description: texto curto e "pushy" (quando/por que usar)
type: instruction | script | mcp          # extensão nossa: como a tool executa
parameters: {"type":"object", ...}         # extensão nossa: JSON Schema da tool
mcp_tool: nome-da-tool-no-gateway          # só para type=mcp
---
"""
import json
import os
import re
import shutil
import subprocess
import sys
import zipfile
from dataclasses import dataclass, field

from app import config

DEFAULT_PARAMETERS = {
    "type": "object",
    "properties": {
        "input": {
            "type": "string",
            "description": "Entrada livre em texto para a skill (contexto, pergunta, dados).",
        }
    },
    "required": [],
}


@dataclass
class Skill:
    name: str
    description: str
    path: str
    type: str = "instruction"
    parameters: dict = field(default_factory=lambda: dict(DEFAULT_PARAMETERS))
    mcp_tool: str | None = None
    body: str = ""

    @property
    def scripts_dir(self):
        return os.path.join(self.path, "scripts")

    @property
    def references_dir(self):
        return os.path.join(self.path, "references")

    @property
    def assets_dir(self):
        return os.path.join(self.path, "assets")

    @property
    def script_path(self):
        # padrão novo: scripts/run.py — mantém compatibilidade com run.py na raiz
        new_style = os.path.join(self.scripts_dir, "run.py")
        old_style = os.path.join(self.path, "run.py")
        if os.path.exists(new_style):
            return new_style
        if os.path.exists(old_style):
            return old_style
        return None

    def list_resources(self) -> dict:
        def _list(d):
            if not os.path.isdir(d):
                return []
            return sorted(
                os.path.relpath(os.path.join(root, f), d)
                for root, _, files in os.walk(d)
                for f in files
            )

        return {
            "scripts": _list(self.scripts_dir),
            "references": _list(self.references_dir),
            "assets": _list(self.assets_dir),
        }


def _parse_frontmatter(text: str) -> tuple[dict, str]:
    m = re.match(r"^---\n(.*?)\n---\n?(.*)$", text, re.DOTALL)
    if not m:
        return {}, text
    fm_text, body = m.groups()
    meta = {}
    for line in fm_text.splitlines():
        if ":" not in line:
            continue
        key, _, value = line.partition(":")
        meta[key.strip()] = value.strip()
    return meta, body.strip()


def _load_skill(name: str, folder: str) -> Skill | None:
    skill_md = os.path.join(folder, "SKILL.md")
    if not os.path.exists(skill_md):
        return None
    with open(skill_md, "r", encoding="utf-8") as f:
        text = f.read()
    meta, body = _parse_frontmatter(text)

    parameters = dict(DEFAULT_PARAMETERS)
    if meta.get("parameters"):
        try:
            parameters = json.loads(meta["parameters"])
        except json.JSONDecodeError:
            pass

    return Skill(
        name=name,
        description=meta.get("description", "(sem descrição)"),
        path=folder,
        type=meta.get("type", "instruction"),
        parameters=parameters,
        mcp_tool=meta.get("mcp_tool"),
        body=body,
    )


def list_skills() -> list[Skill]:
    skills = []
    if not os.path.isdir(config.SKILLS_DIR):
        return skills
    for name in sorted(os.listdir(config.SKILLS_DIR)):
        folder = os.path.join(config.SKILLS_DIR, name)
        if os.path.isdir(folder):
            skill = _load_skill(name, folder)
            if skill:
                skills.append(skill)
    return skills


def get_skill(name: str) -> Skill | None:
    folder = os.path.join(config.SKILLS_DIR, name)
    if os.path.isdir(folder):
        return _load_skill(name, folder)
    return None


def create_skill(
    name: str,
    description: str,
    skill_type: str = "instruction",
    instructions: str = "",
    script_code: str | None = None,
    parameters_schema: dict | None = None,
    mcp_tool: str | None = None,
    references: dict | None = None,
    assets: dict | None = None,
) -> str:
    """
    references/assets: dict {nome_do_arquivo: conteúdo_texto}, gravados em
    references/ e assets/ dentro da pasta da skill (progressive disclosure —
    só entram em contexto quando lidos via read_skill_resource).
    """
    safe_name = re.sub(r"[^a-z0-9\-]+", "-", name.lower()).strip("-")
    folder = os.path.join(config.SKILLS_DIR, safe_name)
    os.makedirs(folder, exist_ok=True)

    fm_lines = [f"description: {description}", f"type: {skill_type}"]
    if parameters_schema:
        fm_lines.append(f"parameters: {json.dumps(parameters_schema, ensure_ascii=False)}")
    if skill_type == "mcp":
        if not mcp_tool:
            raise ValueError("mcp_tool é obrigatório quando skill_type='mcp'")
        fm_lines.append(f"mcp_tool: {mcp_tool}")

    body = instructions or (
        f"Esta skill encapsula a tool MCP '{mcp_tool}'." if skill_type == "mcp" else ""
    )

    skill_md = "---\n" + "\n".join(fm_lines) + "\n---\n\n" + body + "\n"
    with open(os.path.join(folder, "SKILL.md"), "w", encoding="utf-8") as f:
        f.write(skill_md)

    if skill_type == "script":
        if not script_code:
            raise ValueError("script_code é obrigatório quando skill_type='script'")
        scripts_dir = os.path.join(folder, "scripts")
        os.makedirs(scripts_dir, exist_ok=True)
        with open(os.path.join(scripts_dir, "run.py"), "w", encoding="utf-8") as f:
            f.write(script_code)

    if references:
        refs_dir = os.path.join(folder, "references")
        os.makedirs(refs_dir, exist_ok=True)
        for fname, content in references.items():
            with open(os.path.join(refs_dir, fname), "w", encoding="utf-8") as f:
                f.write(content)

    if assets:
        assets_dir = os.path.join(folder, "assets")
        os.makedirs(assets_dir, exist_ok=True)
        for fname, content in assets.items():
            with open(os.path.join(assets_dir, fname), "w", encoding="utf-8") as f:
                f.write(content)

    return safe_name


def delete_skill(name: str):
    folder = os.path.join(config.SKILLS_DIR, name)
    if os.path.isdir(folder):
        shutil.rmtree(folder)


def run_skill_script(skill: Skill, arguments: dict) -> str:
    if not skill.script_path:
        return f"Skill '{skill.name}' não possui script executável (scripts/run.py)."

    # Raiz do projeto no PYTHONPATH: permite que o script (rodando em
    # subprocess isolado) importe módulos do próprio agente, ex:
    #   from app.mcp.client import call_mcp_tool
    #   from app.llm_client import chat_completion, embed
    # Útil para skills que orquestram várias chamadas MCP deterministicamente
    # (ex: publicar N tickets em lote) sem gastar rodadas do loop de tool-calling.
    project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
    env = os.environ.copy()
    env["PYTHONPATH"] = project_root + os.pathsep + env.get("PYTHONPATH", "")

    result = subprocess.run(
        [sys.executable, skill.script_path, json.dumps(arguments, ensure_ascii=False)],
        capture_output=True,
        text=True,
        timeout=120,
        env=env,
        cwd=project_root,
    )
    output = result.stdout.strip()
    if result.returncode != 0:
        output += f"\n[stderr]\n{result.stderr}"
    return output or "(script executou sem saída)"


def read_resource(skill: Skill, resource_path: str) -> str:
    """Lê um arquivo de references/ ou assets/ da skill, com proteção básica
    contra path traversal."""
    base = os.path.abspath(skill.path)
    target = os.path.abspath(os.path.join(skill.path, resource_path))
    if not target.startswith(base):
        return "Caminho inválido."
    if not os.path.exists(target):
        return f"Recurso '{resource_path}' não encontrado na skill '{skill.name}'."
    try:
        with open(target, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    except Exception as e:
        return f"Erro ao ler recurso: {e}"


def package_skill(name: str) -> str:
    """Empacota a skill inteira (SKILL.md + scripts/ + references/ + assets/)
    em um arquivo <nome>.skill (zip), salvo em outputs, pronto pra ser
    baixado/instalado em outro lugar — mesma ideia do package_skill.py."""
    skill = get_skill(name)
    if not skill:
        raise ValueError(f"Skill '{name}' não encontrada.")

    out_path = os.path.join(config.OUTPUTS_DIR, f"{name}.skill")
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, _, files in os.walk(skill.path):
            for file in files:
                full = os.path.join(root, file)
                arcname = os.path.join(name, os.path.relpath(full, skill.path))
                zf.write(full, arcname)
    return out_path
