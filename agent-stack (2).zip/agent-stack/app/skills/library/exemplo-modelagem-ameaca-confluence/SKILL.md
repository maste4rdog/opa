---
description: Analisa uma página do Confluence (arquitetura de sistema, fluxo de dados, etc.), gera requisitos de segurança seguindo STRIDE, publica a análise de volta no Confluence e cria os tickets correspondentes no Jira. Use quando o usuário pedir "modelagem de ameaça", "threat model", "análise de segurança dessa página/arquitetura", ou pedir para gerar requisitos de segurança a partir de um link do Confluence.
type: instruction
parameters: {"type": "object", "properties": {"confluence_url": {"type": "string", "description": "URL da página do Confluence com a arquitetura/fluxo a ser analisado"}, "jira_project_key": {"type": "string", "description": "chave do projeto Jira onde os tickets serão criados, ex: SEC"}}, "required": ["confluence_url", "jira_project_key"]}
---

# Modelagem de Ameaça a partir de página do Confluence

> ⚠️ Este é um TEMPLATE de exemplo. Os nomes exatos das tools MCP
> (`mcp__confluence_...`, `mcp__jira_...`) dependem de como os servers de
> Confluence e Jira estão registrados no SEU MCP Gateway — confira os nomes
> reais na lista de tools antes de usar, e ajuste as chamadas abaixo.

## Quando usar plan_tasks

Este workflow tem 5 passos bem distintos e usa 3 tools diferentes — sempre
chame `plan_tasks` no início com os passos abaixo antes de executar.

## Passo a passo

1. **Buscar o conteúdo da página**
   Chame a tool crua `mcp__confluence_get_page` (ou o nome equivalente no
   seu gateway) com a URL/ID extraído de `confluence_url`. Extraia o texto
   relevante: componentes, fluxos de dados, integrações externas, dados
   sensíveis envolvidos.

2. **Analisar com STRIDE**
   Aplique o checklist em `references/stride-checklist.md` (leia via
   `read_skill_resource` antes de começar). Para cada componente/fluxo
   identificado no passo 1, avalie as 6 categorias STRIDE (Spoofing,
   Tampering, Repudiation, Information Disclosure, Denial of Service,
   Elevation of Privilege) e liste as ameaças plausíveis — não force
   ameaça em categoria que não se aplica.

3. **Gerar requisitos de segurança**
   Para cada ameaça relevante, gere um requisito de mitigação seguindo
   exatamente o formato em `references/formato-requisitos.md` (leia antes
   de gerar). Cada requisito precisa de: ID, descrição da ameaça,
   categoria STRIDE, severidade (Alta/Média/Baixa), requisito de mitigação
   acionável, componente afetado.

4. **Publicar a análise no Confluence**
   Monte o conteúdo da análise (ameaças + requisitos) e chame
   `mcp__confluence_create_page` (como página filha da original, ou
   `mcp__confluence_update_page` se o padrão da equipe for atualizar a
   própria página) com o resultado formatado.

5. **Criar os tickets no Jira**
   Não chame `mcp__jira_create_issue` requisito por requisito — isso gasta
   uma rodada de tool-calling por ticket e pode estourar o limite do loop
   se houver muitos requisitos. Em vez disso, chame a skill
   `skill__exemplo-publicar-requisitos-jira-lote` UMA vez, passando a
   lista inteira de requisitos e o `jira_project_key` — ela cria todos os
   tickets num único script determinístico e devolve os IDs criados.

## Formato de saída pro usuário

Ao final, resuma pro usuário: link da página de análise criada no
Confluence + lista dos tickets Jira criados com seus IDs/links.
