# Formato do requisito de segurança

| Campo | Descrição |
|---|---|
| ID | SEC-REQ-<sequencial> |
| Componente | qual parte da arquitetura é afetada |
| Categoria STRIDE | uma das 6 categorias |
| Ameaça | descrição objetiva do cenário de ataque |
| Severidade | Alta / Média / Baixa |
| Requisito de mitigação | frase acionável, verificável (ex: "Todas as chamadas entre serviço X e Y devem usar mTLS com certificado rotacionado a cada 90 dias") |

Cada requisito vira exatamente 1 ticket no Jira — não agrupe requisitos
diferentes num único ticket.
