# Checklist STRIDE

- **S**poofing — alguém pode se passar por outro usuário/serviço? Autenticação fraca, tokens reutilizáveis, ausência de mTLS entre serviços internos.
- **T**ampering — dados podem ser alterados em trânsito ou em repouso sem detecção? Falta de assinatura/hash, falta de validação de integridade.
- **R**epudiation — uma ação pode ser negada por falta de rastro? Ausência de log de auditoria, logs sem timestamp confiável/imutável.
- **I**nformation Disclosure — dados sensíveis expostos a quem não deveria ver? Dados em claro em logs, respostas de erro verbosas, falta de mascaramento de PII/dados financeiros.
- **D**enial of Service — o componente pode ser derrubado/sobrecarregado? Ausência de rate limiting, falta de circuit breaker, dependência única sem fallback.
- **E**levation of Privilege — alguém pode ganhar mais permissão do que deveria? Escopos OAuth amplos demais, falta de segregação de papéis, validação de autorização só no client.

Adapte a severidade considerando o contexto de instituição financeira
regulada (Bacen/LGPD): exposição de dados de clientes ou falhas em fluxos
de pagamento (Pix/TED/Boleto) tendem a severidade Alta por padrão.
