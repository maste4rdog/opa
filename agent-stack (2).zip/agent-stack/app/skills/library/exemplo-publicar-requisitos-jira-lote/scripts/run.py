"""
Script de exemplo: cria N tickets no Jira a partir de uma lista de
requisitos de segurança, chamando o MCP Gateway diretamente (não passa
pelo loop de tool-calling do agente por ticket).

Requer que o projeto esteja no PYTHONPATH (já é configurado automaticamente
por app/skills/manager.py:run_skill_script) para que os imports abaixo
funcionem mesmo rodando em subprocess.
"""
import json
import sys

from app.mcp.client import call_mcp_tool

# TROQUE pelo nome exato da tool de criação de issue no SEU MCP Gateway
JIRA_CREATE_ISSUE_TOOL = "jira_create_issue"


def main():
    args = json.loads(sys.argv[1])
    project_key = args["jira_project_key"]
    requisitos = args["requisitos"]

    resultados = []
    for req in requisitos:
        summary = f"[{req.get('categoria_stride', 'SEC')}] {req.get('componente', '')} — {req.get('id', '')}"
        description = (
            f"Ameaça: {req.get('ameaca', '')}\n\n"
            f"Severidade: {req.get('severidade', '')}\n\n"
            f"Requisito de mitigação: {req.get('requisito_mitigacao', '')}"
        )

        # Ajuste o payload de arguments conforme o schema real da tool MCP
        # de criação de issue do seu gateway (campos de projeto, tipo de
        # issue, prioridade etc. variam por instalação do Jira).
        arguments = {
            "project_key": project_key,
            "issue_type": "Security Task",
            "summary": summary,
            "description": description,
            "labels": ["threat-modeling", req.get("categoria_stride", "").lower()],
        }

        try:
            result = call_mcp_tool(JIRA_CREATE_ISSUE_TOOL, arguments)
            resultados.append({"requisito_id": req.get("id"), "status": "ok", "resultado": result})
        except Exception as e:
            resultados.append({"requisito_id": req.get("id"), "status": "erro", "erro": str(e)})

    print(json.dumps(resultados, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
