---
description: Cria múltiplos tickets no Jira de uma vez a partir de uma lista de requisitos de segurança, num único passo determinístico (não gasta uma rodada de tool-calling por ticket). Use como sub-etapa depois de gerar requisitos de segurança, nunca chamando o Jira requisito por requisito.
type: script
parameters: {"type": "object", "properties": {"jira_project_key": {"type": "string"}, "requisitos": {"type": "array", "items": {"type": "object", "properties": {"id": {"type": "string"}, "componente": {"type": "string"}, "categoria_stride": {"type": "string"}, "ameaca": {"type": "string"}, "severidade": {"type": "string"}, "requisito_mitigacao": {"type": "string"}}}}}, "required": ["jira_project_key", "requisitos"]}
---

> ⚠️ TEMPLATE de exemplo — troque `"jira_create_issue"` no `scripts/run.py`
> pelo nome exato da tool de criação de issue registrada no seu MCP
> Gateway (confira em `mcp__...` na lista de tools).

Recebe a lista inteira de requisitos e o projeto Jira, cria um ticket por
requisito chamando o MCP Gateway diretamente (sem passar pelo loop de
tool-calling do LLM a cada ticket), e devolve o resultado consolidado.
