---
description: Gera um resumo executivo padronizado (contexto, pontos-chave, riscos, próximos passos) a partir de um texto fornecido.
type: instruction
parameters: {"type": "object", "properties": {"input": {"type": "string", "description": "texto ou conteúdo a ser resumido"}}, "required": ["input"]}
---

Ao usar esta skill, estruture a saída sempre nesta ordem:

1. **Contexto** (1-2 frases)
2. **Pontos-chave** (bullets, máx. 5)
3. **Riscos / pontos de atenção** (bullets)
4. **Próximos passos recomendados** (bullets, acionáveis)

Mantenha tom objetivo, sem floreios. Se o texto de entrada for técnico
(ex: arquitetura de sistema), preserve termos técnicos exatos em vez de
simplificar demais.
