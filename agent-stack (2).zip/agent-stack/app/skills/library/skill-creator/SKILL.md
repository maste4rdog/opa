---
description: Cria novas skills, edita/melhora skills existentes e explica a anatomia correta de uma skill (SKILL.md + scripts/ + references/ + assets/). Use SEMPRE que o usuário pedir para "criar uma skill", "transformar isso numa skill reutilizável", "editar/otimizar uma skill", ou quando você perceber que vai repetir o mesmo processo várias vezes e valeria a pena guardar como skill — mesmo que o usuário não use a palavra "skill".
type: instruction
parameters: {"type": "object", "properties": {"input": {"type": "string", "description": "o que o usuário quer que a skill faça, ou o nome da skill a editar"}}, "required": []}
---

# Skill Creator

Guia para criar e melhorar skills. Sempre que o usuário pedir para criar,
editar ou otimizar uma skill — ou quando um workflow que você acabou de
fazer parece que vai se repetir — siga este processo antes de chamar
`create_skill`.

## Loop principal

1. Capturar intenção
2. Escrever o SKILL.md (rascunho)
3. Testar mentalmente com 1-2 exemplos do próprio usuário
4. Ajustar com base no feedback
5. Empacotar (opcional, via `package_skill`) se o usuário quiser levar a
   skill para outro ambiente

Este ambiente não tem subagents nem browser, então o loop de avaliação
quantitativa automática (evals/benchmark em massa) que eu uso em outros
contextos não se aplica aqui — a validação é qualitativa, com o usuário,
em texto mesmo.

## 1. Capturar intenção

Se a conversa já contém o workflow que o usuário quer virar skill (ex: ele
diz "transforma isso numa skill"), extraia da própria conversa: as
ferramentas usadas, a sequência de passos, formatos de entrada/saída,
correções que o usuário fez no meio do caminho. Confirme com ele antes de
prosseguir.

Perguntas a resolver (pergunte só o que não estiver óbvio pelo contexto):

1. O que essa skill deve permitir o agente fazer?
2. Quando ela deve ser acionada? (que tipo de pedido do usuário)
3. Qual o formato de saída esperado?
4. É uma skill puramente de instrução (o agente segue o texto), uma skill
   de script (lógica determinística em Python) ou um encapsulamento de uma
   tool do MCP Gateway?

## 2. Escrever o SKILL.md

### Anatomia (mesma estrutura usada por mim internamente)

```
nome-da-skill/
├── SKILL.md (obrigatório)
│   ├── frontmatter: description, type, parameters, mcp_tool (se type=mcp)
│   └── corpo em markdown com as instruções
├── scripts/     - código executável (só para type=script)
├── references/  - documentação carregada SOB DEMANDA (não entra em
│                  contexto até o agente chamar read_skill_resource)
└── assets/      - arquivos usados na saída (templates, etc.)
```

### Progressive disclosure — por que isso importa

- **Nível 1 (sempre em contexto):** nome + description. É só isso que ocupa
  espaço na lista de tools o tempo todo. Por isso a description precisa ser
  autoexplicativa.
- **Nível 2 (só quando a skill é chamada):** o corpo do SKILL.md.
- **Nível 3 (só quando explicitamente lido/executado):** arquivos em
  `scripts/`, `references/`, `assets/`.

Não coloque documentação extensa direto no corpo do SKILL.md se ela só é
necessária às vezes — jogue em `references/` e mencione no corpo quando
consultar. Isso mantém a skill barata em contexto na maioria das chamadas.

### Description "pushy"

A description é o ÚNICO sinal que decide se a skill vai ser usada. Eu (e
você, seguindo este guia) tendemos a "sub-acionar" skills — não usar quando
seria útil. Para compensar, a description deve:

- Dizer O QUE a skill faz E QUANDO usar, de forma explícita.
- Listar variações de como o pedido pode aparecer, não só a frase óbvia.

Ruim: `"Gera relatório de vendas."`
Melhor: `"Gera relatório de vendas mensal no padrão da empresa. Use sempre
que o usuário pedir 'relatório de vendas', 'fechamento do mês', 'números de
vendas', ou pedir para consolidar dados de vendas, mesmo que não use a
palavra 'relatório'."`

### Escolhendo o tipo (extensão nossa, não existe no formato original)

- `type: instruction` — a skill é só texto que você (o agente) segue. Use
  para processos, padrões de escrita, checklists, playbooks.
- `type: script` — a skill roda `scripts/run.py` com os argumentos em JSON.
  Use para qualquer coisa que precise ser determinística/repetível (cálculo,
  parsing, chamada de API específica) em vez de deixar o LLM "improvisar"
  toda vez.
- `type: mcp` — a skill é um apelido curado para UMA tool específica do MCP
  Gateway, com nome e parâmetros mais claros que o original. Antes de criar,
  olhe o schema real da tool crua (ela aparece na lista de tools como
  `mcp__<nome>`) para definir os `parameters` corretamente.

### Princípio da não-surpresa

Uma skill não deve fazer nada que o nome/description dela não sugira. Se o
usuário pedir "resumo executivo" e a skill também reformata a ortografia
inteira do texto sem avisar, isso é surpreendente — documente todo
comportamento não-óbvio no corpo do SKILL.md.

### Tamanho

Mantenha o corpo do SKILL.md enxuto (ideal: sob controle, sem virar um
manual). Se estiver crescendo demais, mova o conteúdo detalhado para
`references/algum-topico.md` e deixe no corpo só um ponteiro dizendo quando
consultar aquele arquivo.

## 3. Testar

Sem subagents, o teste é você mesmo simulando: pegue 1-2 exemplos reais que
o usuário daria, "rode" a skill mentalmente seguindo exatamente o que o
SKILL.md diz, e mostre o resultado ao usuário antes de considerar pronta.
Pergunte: "Ficou como você esperava? Mudaria algo?"

## 4. Criar de fato

Depois de alinhado com o usuário, chame `create_skill` com:
- `name`, `description` (seguindo as regras acima), `skill_type`
- `instructions` = o corpo do SKILL.md
- `parameters_schema` (JSON Schema como string) — pense em quais campos
  fazem sentido o próprio agente preencher quando for chamar essa skill
- `script_code` (se `skill_type=script`) — vai para `scripts/run.py`
- `references` / `assets` (opcional) — dict nome_arquivo -> conteúdo, para
  documentação de apoio ou templates

A skill fica disponível imediatamente como a tool `skill__<nome>` — pode
usá-la na mesma resposta, sem esperar o próximo turno do usuário.

## 5. Editar uma skill existente

Preserve o nome original. Chame `create_skill` de novo com o mesmo `name`
(isso sobrescreve o SKILL.md) ajustando só o que precisa mudar. Não crie
`nome-v2` — isso quebra quem já depende do nome da tool `skill__nome`.

## 6. Empacotar (opcional)

Se o usuário quiser levar a skill para outro ambiente, chame
`package_skill(name)` — gera um `.skill` (zip com SKILL.md + scripts/ +
references/ + assets/) em `/data/outputs`, que aparece na sidebar para
download.

---

Resumindo o loop: capturar intenção -> escrever -> testar com exemplo real
-> ajustar -> criar -> (opcional) empacotar.
