import os
from dotenv import load_dotenv

load_dotenv()

LITELLM_BASE_URL = os.getenv("LITELLM_BASE_URL", "http://localhost:4000")
LITELLM_API_KEY = os.getenv("LITELLM_API_KEY", "sk-local")
LLM_MODEL = os.getenv("LLM_MODEL", "gpt-4o")
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "text-embedding-3-small")

MCP_GATEWAY_URL = os.getenv("MCP_GATEWAY_URL", "")
MCP_GATEWAY_TOKEN = os.getenv("MCP_GATEWAY_TOKEN", "")

# Orçamento de tokens reservado pro histórico de conversa antes de cada
# chamada ao LLM (deixa espaço de sobra pra tools + resposta). Ajuste
# conforme a janela de contexto real do modelo configurado no seu LiteLLM.
MAX_CONTEXT_TOKENS = int(os.getenv("MAX_CONTEXT_TOKENS", "16000"))

# Contagem de tokens é aproximada (sem depender de tiktoken/tokenizer real):
# caracteres / CHARS_PER_TOKEN. ~4 é uma média razoável pra texto em
# português/inglês misto. Ajustável se notar desvio grande na prática.
CHARS_PER_TOKEN = float(os.getenv("CHARS_PER_TOKEN", "4"))

# Chunking do RAG, em TOKENS APROXIMADOS (ver CHARS_PER_TOKEN acima)
RAG_CHUNK_TOKENS = int(os.getenv("RAG_CHUNK_TOKENS", "400"))
RAG_CHUNK_OVERLAP_TOKENS = int(os.getenv("RAG_CHUNK_OVERLAP_TOKENS", "60"))

DATA_DIR = os.getenv("DATA_DIR", "./data")
CHROMA_DIR = os.path.join(DATA_DIR, "chroma")
SKILLS_DIR = os.path.join(os.path.dirname(__file__), "skills", "library")
UPLOADS_DIR = os.path.join(DATA_DIR, "uploads")
OUTPUTS_DIR = os.path.join(DATA_DIR, "outputs")
HISTORY_DB = os.path.join(DATA_DIR, "history.sqlite3")

for d in (DATA_DIR, CHROMA_DIR, UPLOADS_DIR, OUTPUTS_DIR, SKILLS_DIR):
    os.makedirs(d, exist_ok=True)
