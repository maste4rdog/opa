"""
Cliente para o SEU MCP Gateway (agregador de vários servers MCP).
Assume que o gateway expõe um endpoint único compatível com o transporte
'streamable-http' do protocolo MCP (padrão em gateways como o do Docker,
mcp-proxy, etc). Se seu gateway usa SSE puro, troque
streamablehttp_client -> sse_client (mesma assinatura de uso).
"""
import asyncio

from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client

from app import config


def _headers():
    h = {}
    if config.MCP_GATEWAY_TOKEN:
        h["Authorization"] = f"Bearer {config.MCP_GATEWAY_TOKEN}"
    return h


async def _list_tools_async():
    if not config.MCP_GATEWAY_URL:
        return []
    async with streamablehttp_client(config.MCP_GATEWAY_URL, headers=_headers()) as (read, write, _):
        async with ClientSession(read, write) as session:
            await session.initialize()
            tools = await session.list_tools()
            return [
                {
                    "name": t.name,
                    "description": t.description or "",
                    "input_schema": t.inputSchema,
                }
                for t in tools.tools
            ]


async def _call_tool_async(tool_name: str, arguments: dict):
    async with streamablehttp_client(config.MCP_GATEWAY_URL, headers=_headers()) as (read, write, _):
        async with ClientSession(read, write) as session:
            await session.initialize()
            result = await session.call_tool(tool_name, arguments)
            texts = []
            for block in result.content:
                if hasattr(block, "text"):
                    texts.append(block.text)
            return "\n".join(texts) if texts else str(result)


def list_mcp_tools() -> list[dict]:
    """Wrapper síncrono, seguro para chamar de dentro do Streamlit."""
    try:
        return asyncio.run(_list_tools_async())
    except Exception as e:
        return [{"error": str(e)}]


def call_mcp_tool(tool_name: str, arguments: dict) -> str:
    try:
        return asyncio.run(_call_tool_async(tool_name, arguments))
    except Exception as e:
        return f"Erro ao chamar tool MCP '{tool_name}': {e}"
