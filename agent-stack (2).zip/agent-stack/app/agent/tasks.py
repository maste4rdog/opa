"""
Lista de tarefas (plano de execução) por sessão de chat — mesma ideia do
TodoWrite do Claude Code: o agente quebra um pedido complexo em passos,
marca 1 por vez como 'in_progress', e vai completando conforme avança.
Isso fica visível pro usuário na sidebar do Streamlit em tempo real.
"""
import sqlite3

from app import config

VALID_STATUSES = ("pending", "in_progress", "completed")


def _conn():
    conn = sqlite3.connect(config.HISTORY_DB)
    conn.execute(
        """CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT,
            position INTEGER,
            content TEXT,
            status TEXT DEFAULT 'pending'
        )"""
    )
    return conn


def set_plan(session_id: str, tasks: list[str]) -> list[dict]:
    with _conn() as conn:
        conn.execute("DELETE FROM tasks WHERE session_id = ?", (session_id,))
        for i, content in enumerate(tasks):
            conn.execute(
                "INSERT INTO tasks (session_id, position, content, status) VALUES (?, ?, ?, ?)",
                (session_id, i, content, "pending"),
            )
    return list_tasks(session_id)


def update_status(session_id: str, task_id: int, status: str) -> list[dict]:
    if status not in VALID_STATUSES:
        status = "pending"
    with _conn() as conn:
        conn.execute(
            "UPDATE tasks SET status = ? WHERE id = ? AND session_id = ?",
            (status, task_id, session_id),
        )
    return list_tasks(session_id)


def list_tasks(session_id: str) -> list[dict]:
    with _conn() as conn:
        rows = conn.execute(
            "SELECT id, content, status FROM tasks WHERE session_id = ? ORDER BY position ASC",
            (session_id,),
        ).fetchall()
    return [{"id": r[0], "content": r[1], "status": r[2]} for r in rows]
