"""
Monta a lista de tools (formato OpenAI function-calling) DINAMICAMENTE a
cada turno do agente e despacha as chamadas.

Fontes das tools:
1. Tools nativas fixas (arquivos, RAG, geração de doc, planejamento, criação
   de skill).
2. Uma tool por SKILL existente em app/skills/library — criada agora,
   disponível já no próximo turno, sem precisar registrar nada manualmente.
3. Tools "cruas" descobertas no MCP Gateway (prefixo mcp__...) — úteis pro
   agente explorar o que existe antes de decidir encapsular algo como skill.
"""
import json
import os

from app import config
from app.agent import tasks
from app.mcp import client as mcp_client
from app.rag import store as rag_store
from app.skills import manager as skills_manager
from app.tools import doc_generator, file_reader

NATIVE_TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "create_skill",
            "description": (
                "Cria uma nova skill, que passa a existir IMEDIATAMENTE como uma tool "
                "própria (nome 'skill__<nome>') disponível no restante desta conversa. "
                "Use skill_type='instruction' para uma skill baseada só em instruções "
                "markdown que você mesmo segue quando chamada; 'script' para lógica "
                "determinística em Python (run.py); 'mcp' para encapsular/curar uma "
                "tool específica já existente no MCP Gateway com um nome e parâmetros "
                "mais claros."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "name": {"type": "string", "description": "nome curto, kebab-case"},
                    "description": {"type": "string"},
                    "skill_type": {
                        "type": "string",
                        "enum": ["instruction", "script", "mcp"],
                        "default": "instruction",
                    },
                    "instructions": {
                        "type": "string",
                        "description": "corpo do SKILL.md em markdown (o que a skill deve fazer/seguir)",
                    },
                    "parameters_schema": {
                        "type": "string",
                        "description": (
                            "JSON Schema (como STRING) dos parâmetros que a tool dessa "
                            "skill vai aceitar quando você mesmo a chamar depois. "
                            "Ex: '{\"type\":\"object\",\"properties\":{\"query\":{\"type\":\"string\"}},\"required\":[\"query\"]}'"
                        ),
                    },
                    "script_code": {
                        "type": "string",
                        "description": (
                            "Código Python completo do run.py, obrigatório se "
                            "skill_type='script'. Deve ler os argumentos via "
                            "json.loads(sys.argv[1]) e imprimir o resultado em stdout."
                        ),
                    },
                    "mcp_tool": {
                        "type": "string",
                        "description": "Nome exato da tool no MCP Gateway (obrigatório se skill_type='mcp').",
                    },
                    "references": {
                        "type": "object",
                        "description": (
                            "Dict {nome_do_arquivo: conteúdo texto} gravado em references/ da "
                            "skill — documentação carregada só sob demanda (via read_skill_resource), "
                            "não entra em contexto toda hora que a skill é chamada."
                        ),
                    },
                    "assets": {
                        "type": "object",
                        "description": "Dict {nome_do_arquivo: conteúdo texto} gravado em assets/ da skill (templates, etc.).",
                    },
                },
                "required": ["name", "description", "skill_type"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "read_skill_resource",
            "description": (
                "Lê um arquivo de references/ ou assets/ de uma skill (progressive disclosure: "
                "só carrega em contexto quando explicitamente pedido)."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "skill_name": {"type": "string"},
                    "resource_path": {"type": "string", "description": "ex: references/formatos.md"},
                },
                "required": ["skill_name", "resource_path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "package_skill",
            "description": "Empacota uma skill (SKILL.md + scripts/ + references/ + assets/) em um arquivo .skill (zip) disponível para download em outputs.",
            "parameters": {
                "type": "object",
                "properties": {"name": {"type": "string"}},
                "required": ["name"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "delete_skill",
            "description": "Remove uma skill existente (e a tool dela deixa de existir no próximo turno).",
            "parameters": {
                "type": "object",
                "properties": {"name": {"type": "string"}},
                "required": ["name"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Lê o conteúdo de um arquivo enviado pelo usuário (pdf, docx, xlsx, csv, txt) pelo nome, em /app/data/uploads.",
            "parameters": {
                "type": "object",
                "properties": {"filename": {"type": "string"}},
                "required": ["filename"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "rag_search",
            "description": "Busca semântica na base de conhecimento (RAG) já ingerida.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {"type": "string"},
                    "k": {"type": "integer", "default": 5},
                },
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "rag_ingest",
            "description": "Ingere um arquivo já enviado (por nome, em /app/data/uploads) na base RAG.",
            "parameters": {
                "type": "object",
                "properties": {"filename": {"type": "string"}},
                "required": ["filename"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "rag_list_sources",
            "description": "Lista as fontes (arquivos) já ingeridas na base RAG e quantos chunks cada uma tem.",
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "rag_delete_source",
            "description": "Remove da base RAG todos os chunks de uma fonte específica (por nome).",
            "parameters": {
                "type": "object",
                "properties": {"source_name": {"type": "string"}},
                "required": ["source_name"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "rag_reset",
            "description": "Apaga TODA a base RAG (todas as fontes). Use com cautela, só se o usuário pedir explicitamente.",
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "generate_document",
            "description": "Gera um documento final (docx, pdf, pptx ou xlsx) em /app/data/outputs.",
            "parameters": {
                "type": "object",
                "properties": {
                    "doc_type": {"type": "string", "enum": ["docx", "pdf", "pptx", "xlsx"]},
                    "title": {"type": "string"},
                    "filename": {"type": "string"},
                    "sections": {"type": "array", "items": {"type": "object"}},
                    "rows": {"type": "array", "items": {"type": "array"}},
                },
                "required": ["doc_type", "title", "filename"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "plan_tasks",
            "description": (
                "Define/substitui o plano de execução da conversa atual como uma lista "
                "ordenada de passos. USE isso sempre que o pedido do usuário envolver 3+ "
                "passos distintos, múltiplas ferramentas, ou trabalho que vai levar vários "
                "turnos — antes de começar a executar. Não use para pedidos triviais de 1 passo."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "tasks": {"type": "array", "items": {"type": "string"}},
                },
                "required": ["tasks"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "update_task",
            "description": (
                "Atualiza o status de UM passo do plano atual. Marque 'in_progress' "
                "antes de começar um passo (só um por vez) e 'completed' assim que "
                "terminar — não acumule vários passos pra marcar completos de uma vez."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "task_id": {"type": "integer"},
                    "status": {"type": "string", "enum": ["pending", "in_progress", "completed"]},
                },
                "required": ["task_id", "status"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "list_tasks",
            "description": "Lista o plano de execução atual e o status de cada passo.",
            "parameters": {"type": "object", "properties": {}},
        },
    },
]


def _skill_tool_schema(skill) -> dict:
    description = skill.description
    if skill.type == "mcp":
        description += f" (encapsula a tool MCP '{skill.mcp_tool}')"
    elif skill.type == "script":
        description += " (executa lógica determinística própria)"
    return {
        "type": "function",
        "function": {
            "name": f"skill__{skill.name}",
            "description": description,
            "parameters": skill.parameters,
        },
    }


def get_mcp_raw_tools_openai_format() -> list[dict]:
    tools = mcp_client.list_mcp_tools()
    formatted = []
    for t in tools:
        if "error" in t:
            continue
        formatted.append(
            {
                "type": "function",
                "function": {
                    "name": f"mcp__{t['name']}",
                    "description": f"[MCP Gateway - cru] {t['description']}",
                    "parameters": t.get("input_schema") or {"type": "object", "properties": {}},
                },
            }
        )
    return formatted


def get_all_tools(include_mcp_raw: bool = True) -> list[dict]:
    tools = list(NATIVE_TOOLS)
    tools += [_skill_tool_schema(s) for s in skills_manager.list_skills()]
    if include_mcp_raw and config.MCP_GATEWAY_URL:
        tools += get_mcp_raw_tools_openai_format()
    return tools


def dispatch_tool_call(name: str, arguments: dict, session_id: str) -> str:
    # --- skill (dinâmica) ---
    if name.startswith("skill__"):
        skill_name = name[len("skill__"):]
        skill = skills_manager.get_skill(skill_name)
        if not skill:
            return f"Skill '{skill_name}' não encontrada."

        if skill.type == "script":
            return skills_manager.run_skill_script(skill, arguments)

        if skill.type == "mcp":
            return mcp_client.call_mcp_tool(skill.mcp_tool, arguments)

        # instruction
        extra_input = arguments.get("input", "")
        text = skill.body
        if extra_input:
            text += f"\n\n---\nEntrada fornecida para esta chamada:\n{extra_input}"
        return text

    # --- tool crua do MCP gateway ---
    if name.startswith("mcp__"):
        real_name = name[len("mcp__"):]
        return mcp_client.call_mcp_tool(real_name, arguments)

    # --- nativas ---
    if name == "create_skill":
        parameters_schema = None
        if arguments.get("parameters_schema"):
            try:
                parameters_schema = json.loads(arguments["parameters_schema"])
            except json.JSONDecodeError:
                return "Erro: parameters_schema não é um JSON válido."
        try:
            safe_name = skills_manager.create_skill(
                name=arguments["name"],
                description=arguments["description"],
                skill_type=arguments.get("skill_type", "instruction"),
                instructions=arguments.get("instructions", ""),
                script_code=arguments.get("script_code"),
                parameters_schema=parameters_schema,
                mcp_tool=arguments.get("mcp_tool"),
                references=arguments.get("references"),
                assets=arguments.get("assets"),
            )
        except ValueError as e:
            return f"Erro ao criar skill: {e}"
        return (
            f"Skill '{safe_name}' criada. Ela já está disponível agora como a tool "
            f"'skill__{safe_name}' — pode chamá-la diretamente."
        )

    if name == "read_skill_resource":
        skill = skills_manager.get_skill(arguments["skill_name"])
        if not skill:
            return f"Skill '{arguments['skill_name']}' não encontrada."
        return skills_manager.read_resource(skill, arguments["resource_path"])

    if name == "package_skill":
        try:
            path = skills_manager.package_skill(arguments["name"])
        except ValueError as e:
            return str(e)
        return f"Skill empacotada em: {path}"

    if name == "delete_skill":
        skills_manager.delete_skill(arguments["name"])
        return f"Skill '{arguments['name']}' removida."

    if name == "read_file":
        path = os.path.join(config.UPLOADS_DIR, arguments["filename"])
        return file_reader.read_file(path)

    if name == "rag_search":
        results = rag_store.search(arguments["query"], k=arguments.get("k", 5))
        return json.dumps(results, ensure_ascii=False)

    if name == "rag_ingest":
        path = os.path.join(config.UPLOADS_DIR, arguments["filename"])
        return rag_store.ingest_file(path, source_name=arguments["filename"])

    if name == "rag_list_sources":
        return json.dumps(rag_store.list_sources(), ensure_ascii=False)

    if name == "rag_delete_source":
        return rag_store.delete_source(arguments["source_name"])

    if name == "rag_reset":
        rag_store.reset()
        return "Base RAG apagada."

    if name == "generate_document":
        doc_type = arguments["doc_type"]
        filename = arguments["filename"]
        title = arguments["title"]
        if doc_type == "docx":
            path = doc_generator.generate_docx(title, arguments.get("sections", []), filename)
        elif doc_type == "pdf":
            path = doc_generator.generate_pdf(title, arguments.get("sections", []), filename)
        elif doc_type == "pptx":
            path = doc_generator.generate_pptx(title, arguments.get("sections", []), filename)
        elif doc_type == "xlsx":
            path = doc_generator.generate_xlsx(title, arguments.get("rows", []), filename)
        else:
            return f"Tipo de documento não suportado: {doc_type}"
        return f"Documento gerado em: {path}"

    if name == "plan_tasks":
        result = tasks.set_plan(session_id, arguments["tasks"])
        return json.dumps(result, ensure_ascii=False)

    if name == "update_task":
        result = tasks.update_status(session_id, arguments["task_id"], arguments["status"])
        return json.dumps(result, ensure_ascii=False)

    if name == "list_tasks":
        return json.dumps(tasks.list_tasks(session_id), ensure_ascii=False)

    return f"Tool desconhecida: {name}"
