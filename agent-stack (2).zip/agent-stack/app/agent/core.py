import json

from app.agent.context_manager import trim_history
from app.agent.tools_registry import dispatch_tool_call, get_all_tools
from app.llm_client import chat_completion

SYSTEM_PROMPT = """Você é um agente assistente em português (pt-BR).

Ferramentas disponíveis (a lista muda dinamicamente durante a conversa):
- Uma tool por SKILL existente, sempre no formato 'skill__<nome>'. Cada
  skill já tem sua própria descrição e parâmetros — chame diretamente
  quando for aplicável, sem precisar de um passo intermediário.
- create_skill / delete_skill / package_skill / read_skill_resource: para
  criar, remover, empacotar (.skill para download) e ler documentação sob
  demanda de uma skill. IMPORTANTE: sempre que o usuário pedir para criar,
  editar ou otimizar uma skill (ou você perceber que um workflow vai se
  repetir e vale guardar como skill), chame 'skill__skill-creator' PRIMEIRO
  para carregar as diretrizes de como escrever uma boa skill, e só depois
  use create_skill. Assim que criada, a skill já vira uma tool chamável
  ('skill__<nome>') — pode usá-la na sequência, na mesma resposta.
- read_file / rag_search / rag_ingest: para trabalhar com arquivos do
  usuário e a base de conhecimento.
- generate_document: para produzir o entregável final (docx/pdf/pptx/xlsx).
- Tools cruas do MCP Gateway (prefixo 'mcp__...'): use para explorar o que
  existe lá antes de decidir se vale a pena encapsular como skill (type='mcp').
- plan_tasks / update_task / list_tasks: quebra de tarefas em passos.

Como planejar (igual você faria com um TODO list):
1. Se o pedido tiver 3+ passos distintos ou for claramente multi-etapa,
   chame plan_tasks ANTES de agir, com os passos em ordem.
2. Antes de começar cada passo, marque-o como 'in_progress' via update_task
   (apenas um passo em andamento por vez).
3. Assim que terminar um passo, marque 'completed' imediatamente — não
   acumule vários passos para marcar de uma vez.
4. Para pedidos simples de 1 passo, não use o plano — apenas responda.

Outras regras:
- Se a resposta depender de um arquivo mencionado, leia-o (ou busque no RAG
  se já foi ingerido) antes de responder.
- Ao criar uma skill do tipo 'mcp', primeiro confira o schema exato da tool
  crua correspondente (ela aparece na lista de tools como 'mcp__<nome>')
  para definir corretamente os parâmetros da skill.
- Seja direto, sem preâmbulos desnecessários.
"""

MAX_TOOL_ROUNDS = 10


def run_agent(history: list[dict], session_id: str) -> str:
    messages = trim_history([{"role": "system", "content": SYSTEM_PROMPT}] + history)

    for _ in range(MAX_TOOL_ROUNDS):
        # Recalcula as tools a cada rodada: se uma skill foi criada na
        # rodada anterior, ela já aparece aqui, disponível na mesma conversa.
        tools = get_all_tools()
        messages = trim_history(messages)

        response = chat_completion(messages=messages, tools=tools)
        choice = response.choices[0]
        msg = choice.message

        if not msg.tool_calls:
            return msg.content or ""

        messages.append(
            {
                "role": "assistant",
                "content": msg.content or "",
                "tool_calls": [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {"name": tc.function.name, "arguments": tc.function.arguments},
                    }
                    for tc in msg.tool_calls
                ],
            }
        )

        for tc in msg.tool_calls:
            try:
                args = json.loads(tc.function.arguments or "{}")
            except json.JSONDecodeError:
                args = {}
            result = dispatch_tool_call(tc.function.name, args, session_id)
            messages.append(
                {
                    "role": "tool",
                    "tool_call_id": tc.id,
                    "content": str(result)[:8000],
                }
            )

    return "Não consegui concluir dentro do limite de chamadas de ferramentas. Tente reformular o pedido."
