"""
RAG local com ChromaDB persistente. Embeddings via LiteLLM (mesmo proxy do
chat, então usa o EMBEDDING_MODEL que você cadastrar lá).

Chunking por tamanho aproximado em TOKENS (via CHARS_PER_TOKEN, sem
depender de tiktoken — ver app/agent/context_manager.py pro mesmo
raciocínio). Overlap entre chunks evita cortar uma frase/ideia bem na
fronteira de dois chunks.
"""
import uuid

import chromadb

from app import config
from app.llm_client import embed
from app.tools.file_reader import read_file

_client = chromadb.PersistentClient(path=config.CHROMA_DIR)
_collection = _client.get_or_create_collection(name="documents")


def _chunk(text: str, chunk_tokens: int | None = None, overlap_tokens: int | None = None) -> list[str]:
    chunk_tokens = chunk_tokens or config.RAG_CHUNK_TOKENS
    overlap_tokens = overlap_tokens or config.RAG_CHUNK_OVERLAP_TOKENS

    chunk_chars = max(1, round(chunk_tokens * config.CHARS_PER_TOKEN))
    overlap_chars = max(0, round(overlap_tokens * config.CHARS_PER_TOKEN))

    chunks = []
    start = 0
    while start < len(text):
        end = start + chunk_chars
        piece = text[start:end]
        if piece.strip():
            chunks.append(piece)
        start = end - overlap_chars
    return chunks


def ingest_file(path: str, source_name: str | None = None) -> str:
    text = read_file(path)
    if text.startswith("Erro ao ler") or text.startswith("Arquivo não encontrado"):
        return text

    chunks = _chunk(text)
    if not chunks:
        return "Nenhum conteúdo extraído do arquivo."

    embeddings = embed(chunks)
    ids = [str(uuid.uuid4()) for _ in chunks]
    metadatas = [{"source": source_name or path, "chunk": i} for i in range(len(chunks))]

    _collection.add(ids=ids, embeddings=embeddings, documents=chunks, metadatas=metadatas)
    return (
        f"Ingeridos {len(chunks)} trechos (~{config.RAG_CHUNK_TOKENS} tokens cada, "
        f"overlap {config.RAG_CHUNK_OVERLAP_TOKENS}) de '{source_name or path}' na base RAG."
    )


def search(query: str, k: int = 5) -> list[dict]:
    if _collection.count() == 0:
        return []
    query_embedding = embed([query])[0]
    results = _collection.query(query_embeddings=[query_embedding], n_results=k)

    out = []
    docs = results.get("documents", [[]])[0]
    metas = results.get("metadatas", [[]])[0]
    dists = results.get("distances", [[]])[0]
    for doc, meta, dist in zip(docs, metas, dists):
        out.append({"text": doc, "source": meta.get("source"), "distance": dist})
    return out


def list_sources() -> list[dict]:
    """Lista as fontes já ingeridas e quantos chunks cada uma tem."""
    if _collection.count() == 0:
        return []
    data = _collection.get(include=["metadatas"])
    counts: dict[str, int] = {}
    for meta in data.get("metadatas", []):
        source = meta.get("source", "desconhecido")
        counts[source] = counts.get(source, 0) + 1
    return [{"source": s, "chunks": c} for s, c in sorted(counts.items())]


def delete_source(source_name: str) -> str:
    """Remove todos os chunks de uma fonte específica."""
    _collection.delete(where={"source": source_name})
    return f"Chunks da fonte '{source_name}' removidos."


def reset():
    """Apaga TODA a base RAG (todas as fontes)."""
    global _collection
    _client.delete_collection("documents")
    _collection = _client.get_or_create_collection(name="documents")
