import os

import streamlit as st

from app import config
from app.agent import tasks as tasks_store
from app.agent.core import run_agent
from app.db import history as db
from app.rag import store as rag_store
from app.skills import manager as skills_manager

st.set_page_config(page_title="Agente", page_icon="🤖", layout="wide")

# ---------- estado ----------
if "session_id" not in st.session_state:
    sessions = db.list_sessions()
    st.session_state.session_id = sessions[0]["id"] if sessions else db.create_session()

# ---------- sidebar ----------
with st.sidebar:
    st.title("🤖 Agente")

    if st.button("➕ Nova conversa", use_container_width=True):
        st.session_state.session_id = db.create_session()
        st.rerun()

    st.subheader("Conversas")
    for s in db.list_sessions():
        cols = st.columns([4, 1])
        label = s["title"] or "Sem título"
        if cols[0].button(label, key=f"sess_{s['id']}", use_container_width=True):
            st.session_state.session_id = s["id"]
            st.rerun()
        if cols[1].button("🗑️", key=f"del_{s['id']}"):
            db.delete_session(s["id"])
            if st.session_state.session_id == s["id"]:
                st.session_state.session_id = db.create_session()
            st.rerun()

    st.divider()
    st.subheader("📚 Base RAG")
    sources = rag_store.list_sources()
    if not sources:
        st.caption("Nenhum documento ingerido ainda.")
    else:
        for s in sources:
            st.caption(f"{s['source']} — {s['chunks']} chunks")

    st.divider()
    st.subheader("📎 Upload de arquivo")
    uploaded = st.file_uploader("Enviar arquivo", type=["pdf", "docx", "xlsx", "csv", "txt"])
    if uploaded is not None:
        dest = os.path.join(config.UPLOADS_DIR, uploaded.name)
        with open(dest, "wb") as f:
            f.write(uploaded.getbuffer())
        st.success(f"'{uploaded.name}' salvo. Peça ao agente para ler ou ingerir no RAG.")

    st.divider()
    st.subheader("🧩 Skills disponíveis")
    skills = skills_manager.list_skills()
    if not skills:
        st.caption("Nenhuma skill criada ainda. Peça ao agente para criar uma.")
    for skill in skills:
        badge = {"instruction": "📝", "script": "⚙️", "mcp": "🔌"}.get(skill.type, "🧩")
        with st.expander(f"{badge} {skill.name} ({skill.type})"):
            st.caption(skill.description)
            if skill.type == "mcp":
                st.code(f"mcp_tool: {skill.mcp_tool}", language="text")
            resources = skill.list_resources()
            for kind, files in resources.items():
                if files:
                    st.caption(f"{kind}/: " + ", ".join(files))
            c1, c2 = st.columns(2)
            if c1.button("📦 Empacotar", key=f"pkg_skill_{skill.name}"):
                skills_manager.package_skill(skill.name)
                st.rerun()
            if c2.button("🗑️ Remover", key=f"del_skill_{skill.name}"):
                skills_manager.delete_skill(skill.name)
                st.rerun()

    st.divider()
    st.subheader("📋 Plano da conversa")
    plan = tasks_store.list_tasks(st.session_state.session_id)
    if not plan:
        st.caption("Sem plano ativo nesta conversa.")
    else:
        icons = {"pending": "⬜", "in_progress": "🔵", "completed": "✅"}
        for t in plan:
            st.markdown(f"{icons.get(t['status'], '⬜')} {t['content']}")

    st.divider()
    st.subheader("📄 Documentos gerados")
    outputs = sorted(os.listdir(config.OUTPUTS_DIR)) if os.path.isdir(config.OUTPUTS_DIR) else []
    for fname in outputs:
        fpath = os.path.join(config.OUTPUTS_DIR, fname)
        with open(fpath, "rb") as f:
            st.download_button(fname, f.read(), file_name=fname, key=f"dl_{fname}")

# ---------- chat principal ----------
st.header("Chat")

messages = db.load_messages(st.session_state.session_id)
for m in messages:
    with st.chat_message(m["role"]):
        st.markdown(m["content"])

user_input = st.chat_input("Digite sua mensagem...")
if user_input:
    db.save_message(st.session_state.session_id, "user", user_input)

    # título automático da sessão na primeira mensagem
    if len(messages) == 0:
        db.rename_session(st.session_state.session_id, user_input[:60])

    with st.chat_message("user"):
        st.markdown(user_input)

    history = db.load_messages(st.session_state.session_id)

    with st.chat_message("assistant"):
        with st.spinner("Pensando..."):
            reply = run_agent(history, st.session_state.session_id)
        st.markdown(reply)

    db.save_message(st.session_state.session_id, "assistant", reply)
    st.rerun()
