# Guia de Uso

Este arquivo ensina: como rodar nos dois modos, como adicionar novos MCPs
e tools, como usar o RAG, e como o sistema trata janela de contexto e
chunking. Para visão geral de arquitetura, veja o `README.md`.

---

## 1. Rodando nos dois modos

### Docker

```bash
cp .env.example .env
# edite .env com LITELLM_BASE_URL/KEY, LLM_MODEL, EMBEDDING_MODEL, MCP_GATEWAY_URL
docker compose up --build
```

Pra parar: `docker compose down`. Pra ver logs: `docker compose logs -f app`.
Os dados (SQLite, ChromaDB, uploads, outputs) ficam em `./data`, montado
como volume — sobrevivem a rebuilds.

### Python puro (sem Docker)

```bash
./run_local.sh          # Linux/Mac
.\run_local.ps1         # Windows (PowerShell)
```

Ou manualmente:
```bash
python3 -m venv .venv
source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env          # edite antes de rodar de novo
streamlit run app/streamlit_app.py
```

Os dados ficam em `./data` na pasta do projeto (mesmo comportamento do
Docker, só que sem volume — é o filesystem local direto).

**Diferença prática entre os dois modos:** só a forma como o processo sobe
e como ele enxerga rede (`localhost` direto no modo local vs.
`host.docker.internal` ou nome de serviço docker no modo container). O
código Python em `app/` é idêntico nos dois.

---

## 2. Como adicionar novos MCPs e tools

Existem 3 caminhos, do mais simples ao mais trabalhoso:

### 2.1. Adicionar um server novo no seu MCP Gateway (nada a fazer aqui)

Se você já tem um MCP Gateway agregando vários servers, basta registrar o
novo server **nele**. O agente descobre tudo sozinho: a cada turno,
`get_all_tools()` chama `list_tools()` do gateway (`app/mcp/client.py`) e
expõe cada tool crua como `mcp__<nome>`, com o schema de parâmetros exato
que o server MCP declarou. Zero código novo neste repo.

Trade-off: o nome/descrição da tool é o que o server MCP original definiu
— às vezes técnico demais ou mal descrito pro seu caso de uso.

### 2.2. Curar uma tool MCP como skill (nome e descrição melhores)

Se uma tool MCP crua existe mas o nome/descrição dela é ruim, ou você quer
fixar alguns parâmetros, peça ao agente pra criar uma skill `type=mcp`:

> "Cria uma skill chamada `consultar-saldo-pix` que usa a tool MCP
> `pix.balance.get`, só com o parâmetro `account_id`."

O agente (via `skill__skill-creator`) primeiro olha o schema real da tool
crua (`mcp__pix.balance.get`, já visível na lista de tools) e depois chama
`create_skill(skill_type="mcp", mcp_tool="pix.balance.get", ...)`. A partir
daí existe `skill__consultar-saldo-pix` com nome e descrição melhores,
repassando a chamada pro MCP por baixo.

### 2.3. Tool nativa nova em Python (sem MCP)

Pra algo que não vem de um server MCP — ex: uma chamada HTTP pra uma API
interna sua, uma função determinística que não faz sentido como "skill" —
edite `app/agent/tools_registry.py` direto:

1. Adicione o schema em `NATIVE_TOOLS` (formato OpenAI function-calling):
   ```python
   {
       "type": "function",
       "function": {
           "name": "consultar_taxa_selic",
           "description": "Consulta a taxa Selic atual via API do Bacen.",
           "parameters": {
               "type": "object",
               "properties": {},
           },
       },
   },
   ```
2. Trate a chamada em `dispatch_tool_call`:
   ```python
   if name == "consultar_taxa_selic":
       import httpx
       resp = httpx.get("https://api.bcb.gov.br/...")
       return resp.text
   ```
3. Pronto — na próxima mensagem a tool já aparece pro agente, sem reiniciar
   nada (o Streamlit recarrega o módulo a cada rerun).

Use isso só para lógica de baixo nível/infra. Se é algo específico do
domínio (um processo, um formato de saída) prefira criar uma **skill**
(`type=script`) em vez de mexer em código — fica editável pelo próprio
agente e visível/documentado junto com as outras skills.

---

## 3. Como usar o RAG

### Ingerir um documento

Pela sidebar: faça upload do arquivo (pdf, docx, xlsx, csv, txt), depois
peça no chat: *"ingere o arquivo que acabei de enviar na base RAG"*. O
agente chama `rag_ingest(filename)`, que lê o arquivo, quebra em chunks e
gera embeddings via o `EMBEDDING_MODEL` do seu LiteLLM.

### Buscar

O agente decide sozinho quando chamar `rag_search(query, k=5)` — por
exemplo, se você pergunta algo que parece depender de um documento já
ingerido. Cada resultado vem com `text`, `source` (nome do arquivo
original) e `distance` (quanto menor, mais similar semanticamente).

### Gerenciar

- `rag_list_sources` — lista os arquivos ingeridos e quantos chunks cada um
  tem (também aparece direto na sidebar, seção "📚 Base RAG").
- `rag_delete_source(source_name)` — remove só os chunks de um arquivo.
- `rag_reset` — apaga a base inteira.

Peça isso normalmente no chat: *"lista o que já tá na base RAG"*, *"remove
o relatorio-antigo.pdf da base"*.

### Limitações atuais (transparência)

- Busca é puramente semântica (por embedding) — não tem filtro por
  metadado além da fonte (`rag_delete_source`), nem busca híbrida
  (semântica + palavra-chave/BM25).
- Um único "balde" (`documents`) pra tudo que é ingerido — não tem
  namespaces/coleções separadas por assunto. Se isso virar necessidade real
  (ex: separar RAG de contratos vs. RAG de documentação técnica), dá pra
  estender `rag/store.py` pra usar `_client.get_or_create_collection(name=...)`
  parametrizado.

---

## 4. Janela de contexto e chunking — como é tratado hoje

### Chunking do RAG (`app/rag/store.py`)

Chunking é por **tokens**, não por caracteres (usando `tiktoken`,
`cl100k_base`):

- `RAG_CHUNK_TOKENS` (padrão 400) — tamanho de cada chunk.
- `RAG_CHUNK_OVERLAP_TOKENS` (padrão 60) — sobreposição entre chunks
  consecutivos, pra não cortar uma frase/ideia bem na fronteira.

Por que tokens e não caracteres: é a unidade que realmente importa pro
limite do embedding model e, depois, pro orçamento de contexto do LLM que
vai ler os chunks recuperados. Caracteres não mapeiam 1:1 pra tokens,
principalmente em PT-BR (acentuação, "ç", etc. variam bastante dependendo
do tokenizer). Ambos os valores são configuráveis via `.env`.

`cl100k_base` é uma aproximação (é o encoding usado pelos modelos GPT-4/
GPT-3.5 da OpenAI) — como o LiteLLM pode rotear pra provedores diferentes
(Anthropic, etc.) sem tokenizer idêntico exposto publicamente, essa é a
contagem usada como heurística consistente em todo o sistema. Na prática a
diferença real entre tokenizers é pequena o suficiente pra não importar
pro propósito de "não estourar o limite".

### Janela de contexto da conversa (`app/agent/context_manager.py`) — **novo**

Antes desta versão, **não havia nenhum controle**: o histórico inteiro
salvo no SQLite era reenviado ao LLM a cada turno, sem limite — em
conversas longas isso eventualmente estoura a janela do modelo. Agora:

1. `MAX_CONTEXT_TOKENS` (padrão 16000, configurável no `.env`) define o
   orçamento de tokens reservado pro histórico + system prompt, antes de
   cada chamada ao LLM (deixando espaço de sobra pra tools + resposta).
2. As mensagens são agrupadas em **blocos**: cada bloco começa numa
   mensagem `system` ou `user` e inclui tudo que vier depois (respostas do
   assistant, chamadas de tool e resultados de tool) até o próximo bloco.
   Isso é importante — nunca cortamos uma mensagem `assistant` com
   `tool_calls` separada do `tool` que responde a ela, pois isso quebraria
   a conversa pro formato da API.
3. O bloco de `system` (system prompt) é sempre mantido. Dos blocos
   restantes, mantemos os **mais recentes** que couberem no orçamento,
   descartando os mais antigos primeiro.
4. Se algo foi descartado, um aviso curto é inserido no lugar (visível pro
   LLM, não pro usuário na UI) avisando que houve corte.
5. Isso roda uma vez no início de cada turno e de novo a cada rodada dentro
   do loop de tool-calling (útil quando o agente faz várias chamadas de
   tool seguidas no mesmo turno e o resultado das tools vai inflando o
   contexto).

Além disso, cada resultado individual de tool já é truncado em 8000
caracteres (`core.py`) antes de entrar na conversa — protege contra uma
tool que devolva algo enorme (ex: um arquivo grande lido via `read_file`)
estourar sozinha o orçamento de um turno.

### O que isso NÃO faz (limitações conscientes)

- Não resume/sumariza o conteúdo descartado — só corta. Se seu caso de uso
  precisa "lembrar" de coisas muito antigas da conversa, a alternativa é:
  (a) aumentar `MAX_CONTEXT_TOKENS` se o modelo aguenta, ou (b) implementar
  uma etapa de sumarização dos blocos descartados antes de removê-los
  (viável como próxima melhoria, mas custa uma chamada extra ao LLM).
- A contagem de tokens é uma aproximação (`cl100k_base` universal), não o
  tokenizer exato do modelo ativo no seu LiteLLM. Na prática costuma ficar
  próxima o suficiente pra esse propósito.
- Histórico persistido no SQLite (`app/db/history.py`) guarda a conversa
  **inteira**, sem limite — o corte só acontece na hora de montar o
  request pro LLM. Ou seja, você nunca perde histórico de vista na UI,
  só que o modelo não "vê" tudo em turnos muito longos.
