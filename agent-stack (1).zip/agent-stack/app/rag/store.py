"""
RAG local com ChromaDB persistente. Embeddings via LiteLLM (mesmo proxy do
chat, então usa o EMBEDDING_MODEL que você cadastrar lá).

Chunking por TOKENS (tiktoken, cl100k_base), não por caracteres — mais
preciso porque o limite real que importa (contexto do embedding model e do
LLM na hora de montar a resposta) é em tokens, e caracteres não mapeiam
1:1 pra tokens especialmente em PT-BR (acentos, ç, etc. variam o
tokenizer). Overlap entre chunks evita cortar uma frase/ideia bem no meio
da fronteira de dois chunks.
"""
import uuid

import chromadb
import tiktoken

from app import config
from app.llm_client import embed
from app.tools.file_reader import read_file

_client = chromadb.PersistentClient(path=config.CHROMA_DIR)
_collection = _client.get_or_create_collection(name="documents")
_encoding = tiktoken.get_encoding("cl100k_base")


def _chunk(text: str, chunk_tokens: int | None = None, overlap_tokens: int | None = None) -> list[str]:
    chunk_tokens = chunk_tokens or config.RAG_CHUNK_TOKENS
    overlap_tokens = overlap_tokens or config.RAG_CHUNK_OVERLAP_TOKENS

    tokens = _encoding.encode(text)
    chunks = []
    start = 0
    while start < len(tokens):
        end = start + chunk_tokens
        piece = _encoding.decode(tokens[start:end])
        if piece.strip():
            chunks.append(piece)
        start = end - overlap_tokens
    return chunks


def ingest_file(path: str, source_name: str | None = None) -> str:
    text = read_file(path)
    if text.startswith("Erro ao ler") or text.startswith("Arquivo não encontrado"):
        return text

    chunks = _chunk(text)
    if not chunks:
        return "Nenhum conteúdo extraído do arquivo."

    embeddings = embed(chunks)
    ids = [str(uuid.uuid4()) for _ in chunks]
    metadatas = [{"source": source_name or path, "chunk": i} for i in range(len(chunks))]

    _collection.add(ids=ids, embeddings=embeddings, documents=chunks, metadatas=metadatas)
    return (
        f"Ingeridos {len(chunks)} trechos (~{config.RAG_CHUNK_TOKENS} tokens cada, "
        f"overlap {config.RAG_CHUNK_OVERLAP_TOKENS}) de '{source_name or path}' na base RAG."
    )


def search(query: str, k: int = 5) -> list[dict]:
    if _collection.count() == 0:
        return []
    query_embedding = embed([query])[0]
    results = _collection.query(query_embeddings=[query_embedding], n_results=k)

    out = []
    docs = results.get("documents", [[]])[0]
    metas = results.get("metadatas", [[]])[0]
    dists = results.get("distances", [[]])[0]
    for doc, meta, dist in zip(docs, metas, dists):
        out.append({"text": doc, "source": meta.get("source"), "distance": dist})
    return out


def list_sources() -> list[dict]:
    """Lista as fontes já ingeridas e quantos chunks cada uma tem."""
    if _collection.count() == 0:
        return []
    data = _collection.get(include=["metadatas"])
    counts: dict[str, int] = {}
    for meta in data.get("metadatas", []):
        source = meta.get("source", "desconhecido")
        counts[source] = counts.get(source, 0) + 1
    return [{"source": s, "chunks": c} for s, c in sorted(counts.items())]


def delete_source(source_name: str) -> str:
    """Remove todos os chunks de uma fonte específica."""
    _collection.delete(where={"source": source_name})
    return f"Chunks da fonte '{source_name}' removidos."


def reset():
    """Apaga TODA a base RAG (todas as fontes)."""
    global _collection
    _client.delete_collection("documents")
    _collection = _client.get_or_create_collection(name="documents")
