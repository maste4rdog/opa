"""
Gestão de janela de contexto.

Problema que isso resolve: sem isso, o histórico inteiro da conversa (todas
as mensagens salvas no SQLite) seria reenviado pro LLM a cada turno, sem
limite — em conversas longas isso estoura a janela de contexto do modelo
(ou fica caro/lento bem antes disso).

Estratégia:
1. Contamos tokens com tiktoken (encoding cl100k_base — aproximação boa o
   suficiente pra qualquer modelo por trás do LiteLLM, já que não temos o
   tokenizer exato de cada provedor).
2. Agrupamos as mensagens em "blocos": cada bloco começa numa mensagem de
   'system' ou 'user' e inclui tudo que vier depois (respostas do
   assistant, chamadas de tool, resultados de tool) até o próximo bloco.
   Isso garante que nunca cortamos uma mensagem 'assistant' com
   tool_calls separada do 'tool' que responde a ela — cortar no meio
   quebraria a conversa pro LLM.
3. Sempre mantemos o bloco de system (primeiro). Dos blocos restantes,
   mantemos os mais RECENTES que couberem no orçamento de tokens
   (MAX_CONTEXT_TOKENS), descartando os mais antigos primeiro.
4. Se algo foi descartado, inserimos um aviso curto no lugar, pra deixar
   claro (pro LLM e, se você expuser, pro usuário) que houve corte.

Isso é chamado uma vez no início de cada turno (antes do loop de tool
calling), não a cada rodada dentro do mesmo turno.
"""
import tiktoken

from app import config

_encoding = tiktoken.get_encoding("cl100k_base")


def count_tokens(text: str) -> int:
    if not text:
        return 0
    return len(_encoding.encode(text))


def _message_tokens(msg: dict) -> int:
    tokens = count_tokens(msg.get("content") or "") + 4  # overhead fixo aproximado
    if msg.get("tool_calls"):
        tokens += count_tokens(str(msg["tool_calls"]))
    return tokens


def _group_into_blocks(messages: list[dict]) -> list[list[dict]]:
    blocks = []
    current = []
    for msg in messages:
        if msg["role"] in ("system", "user") and current:
            blocks.append(current)
            current = [msg]
        else:
            current.append(msg)
    if current:
        blocks.append(current)
    return blocks


def trim_history(messages: list[dict], max_tokens: int | None = None) -> list[dict]:
    max_tokens = max_tokens or config.MAX_CONTEXT_TOKENS
    if not messages:
        return messages

    blocks = _group_into_blocks(messages)
    system_block = blocks[0] if blocks and blocks[0][0]["role"] == "system" else None
    rest_blocks = blocks[1:] if system_block else blocks

    system_tokens = sum(_message_tokens(m) for m in system_block) if system_block else 0
    budget = max_tokens - system_tokens

    kept_blocks = []
    total = 0
    for block in reversed(rest_blocks):
        block_tokens = sum(_message_tokens(m) for m in block)
        if total + block_tokens > budget and kept_blocks:
            # sempre mantém pelo menos o bloco mais recente, mesmo estourando
            break
        kept_blocks.append(block)
        total += block_tokens
    kept_blocks.reverse()

    dropped = len(rest_blocks) - len(kept_blocks)

    result = list(system_block) if system_block else []
    if dropped > 0:
        result.append(
            {
                "role": "system",
                "content": (
                    f"[Aviso de contexto: {dropped} trecho(s) mais antigo(s) da conversa "
                    "foram removidos por limite de tokens. Se precisar de algo específico "
                    "de antes, peça ao usuário para relembrar.]"
                ),
            }
        )
    for block in kept_blocks:
        result.extend(block)
    return result
